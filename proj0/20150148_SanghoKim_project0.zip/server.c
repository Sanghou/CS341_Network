#include <stdio.h>

int main (void) {
	printf("server running \n");
}
