#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netdb.h>
//1byte = 8 bit.
//char 8bit
//int 32bit
//long long 64bit
#define MAX_LENGTH 10000000 //unit is byte. 10MB
#define MAX_PACKET_SIZE 9999992
#define MALLOC_SIZE 1000*1000 //1KB malloc

struct packet {
	char op; //8bit
	char shift; //8bit;
	short checksum; //16bit;
	unsigned int length; //32bit;
	char* string; //data;
};

char *read_user_input (void);
unsigned short checksum2(const char *buf, unsigned size);


void main (int argc, char **argv) {
	int c; //argument

	char *ipAddress; //h
  char *portNumber; //p
  int encrypt; //o
  int shift; //s

  char* buffer;

  int numbytes;

  int status;
  struct addrinfo hints;
  struct addrinfo *servinfo;

  int index;

  opterr = 0;

  while ((c = getopt (argc, argv, "h:p:o:s:")) != -1) {
    switch (c)
      {
      case 'h':
        ipAddress = optarg;
        break;
      case 'p':
        portNumber = optarg;
        break;
      case 'o':
      	encrypt = atoi(optarg);
        break;
      case 's':
      	shift = atoi(optarg);
        break;
      default:
      	printf("other language %s \n", c);
        abort ();
      }
  }


  // printf ("ipAddress = %s, portNumber = %s, shift = %d, encrypt=%d \n ",ipAddress, portNumber, shift, encrypt);

  for (index = optind; index < argc; index++)
    printf ("Non-option argument %s\n", argv[index]);
  
  //connect to server.
  // printf("before read user input \n\n");
  buffer = read_user_input();

  // printf("size ::: %d \n", strlen(buffer));


// struct packet {
// 	char op; //8bit 1byte
// 	char shift; //8bit; 1byte
// 	short checksum; //16bit; 2byte
// 	unsigned int length; //32bit; 4byte
// 	char* string; //data;
// };

  //create packet. 
  //shift, encrypt, buffer를 쓰자.
  unsigned char *msg;
  unsigned int length;

  // printf("buffer len : %d \n", strlen(buffer));
  msg = (unsigned char *) malloc(8 + strlen(buffer));

  // printf("msg : %d \n", msg);
  memcpy(msg, &encrypt, 1); //op
  memcpy(msg + 1, &shift, 1); //shift msg+1byte부터 시작함.
  length = htonl(strlen(buffer) + 8);
  memcpy(msg + 4, &length, 4);
  memcpy(msg + 8, buffer, strlen(buffer));
  unsigned short checksum = checksum2(msg, htonl(length));
  memcpy(msg+2 , &checksum, 2);
  // printf("shift : %d \n", *(msg+1));
  // printf("length : %d \n", htonl(length));
  // printf("op :%d \n", *msg);
  // printf("shift : %d \n", *(msg+1));
  // printf("checksum : %d \n", *(msg + 2));
  // printf("length : %d \n", *(msg + 4));
  // printf("%s \n", msg+8);


  memset(&hints, 0, sizeof hints);
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;

  if ((status = getaddrinfo(ipAddress, portNumber, &hints, &servinfo)) != 0) {
    fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
    exit(1);
  }
  // printf("%d \n",status);
  // printf("after make socket \n");
  int socket_fd;
  int check;
  socket_fd = socket(servinfo->ai_family, servinfo->ai_socktype, servinfo->ai_protocol);
  bind(socket_fd, servinfo->ai_addr, servinfo->ai_addrlen);
  // printf("socket_fd : %d \n", socket_fd);
  check = connect(socket_fd, servinfo->ai_addr, servinfo->ai_addrlen);
  // printf("connect : %d \n", check);
  

  // check = send(socket_fd, buffer, strlen(buffer), 0);
  



  check = send(socket_fd, msg, htonl(length), 0);
  // printf("size of packet : %d %d\n", htonl(length), strlen(buffer) + 8);
  // printf("send return : %d \n", check);

  //윤성우 열혈 TCP/IP 소켓 프로그래밍 Chapter 05-1 P.126

  int recv_len = 0;
  int recv_cnt = 0;

  while(recv_len < htonl(length)) {
  	if((recv_cnt=recv(socket_fd, &buffer[recv_len], htonl(length),0)) == -1) {
  		perror("recv");
  		exit(1);
  	}
  	recv_len += recv_cnt;
  	// printf("recv_len: %d \n", recv_len);
  }

  // if((numbytes=recv(socket_fd, buffer, strlen(buffer) + 8,0)) == -1) {
  // 		perror("recv");
  // 		exit(1);
  // }
  // printf("received length : %d \n", numbytes);
  // buffer[numbytes] = '\0';
	// printf("client: received \n%s", buffer + 8);
  close(socket_fd);
  // printf("buffer? %s \n", buffer);


  //리턴시 풀어서 제출해주자.
  fputs(buffer+8 , stdout);
	freeaddrinfo(servinfo);
	free(msg);
  return 0;
}

struct packet *make_packet(char *buffer, char *ipAddress, char *portNumber, int shift, int encrypt) {

};

char *read_user_input (void) {
	// printf("start read_user int \n");
	char *buffer = NULL;

	unsigned long long size = 0;
	unsigned len = 0;
	unsigned last = 0;

	do {
		// printf("size up! \n");
		size += MALLOC_SIZE;
		buffer = realloc(buffer, size);
		fgets(buffer + len, MALLOC_SIZE, stdin);
		len = strlen(buffer);
		last = len - 1;
		// printf("size : %d, len: %d, last: %d \n ", size, len, last);
	} while (!feof(stdin) && buffer[last] != '\n');

	// fgets(buffer, MALLOC_SIZE* sizeof(buffer), stdin);
  // printf("%d \n",strlen(buffer));

  return buffer;
}	





unsigned short checksum2(const char *buf, unsigned size)
{
	unsigned long long sum = 0;
	const unsigned long long *b = (unsigned long long *) buf;

	unsigned t1, t2;
	unsigned short t3, t4;

	/* Main loop - 8 bytes at a time */
	while (size >= sizeof(unsigned long long))
	{
		unsigned long long s = *b++;
		sum += s;
		if (sum < s) sum++;
		size -= 8;
	}

	/* Handle tail less than 8-bytes long */
	buf = (const char *) b;
	if (size & 4)
	{
		unsigned s = *(unsigned *)buf;
		sum += s;
		if (sum < s) sum++;
		buf += 4;
	}

	if (size & 2)
	{
		unsigned short s = *(unsigned short *) buf;
		sum += s;
		if (sum < s) sum++;
		buf += 2;
	}

	if (size)
	{
		unsigned char s = *(unsigned char *) buf;
		sum += s;
		if (sum < s) sum++;
	}

	/* Fold down to 16 bits */
	t1 = sum;
	t2 = sum >> 32;
	t1 += t2;
	if (t1 < t2) t1++;
	t3 = t1;
	t4 = t1 >> 16;
	t3 += t4;
	if (t3 < t4) t3++;

	return ~t3;
}